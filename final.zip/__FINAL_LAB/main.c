// Main.c
// Runs on LM4F120/TM4C123
// Use Timer2A in 32-bit periodic mode to request interrupts at a periodic rate
// Daniel Valvano
// May 5, 2015

/* This example accompanies the book
   "Embedded Systems: Real Time Interfacing to Arm Cortex M Microcontrollers",
   ISBN: 978-1463590154, Jonathan Valvano, copyright (c) 2015
  Program 7.5, example 7.6

 Copyright 2015 by Jonathan W. Valvano, valvano@mail.utexas.edu
    You may use, edit, run or distribute this file
    as long as the above copyright notice remains
 THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
 OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
 MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
 VALVANO SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL,
 OR CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/
 */

// oscilloscope or LED connected to PF3-1 for period measurement
// When using the color wheel, the blue LED on PF2 is on for four
// consecutive interrupts then off for four consecutive interrupts.
// Blue is off for: dark, red, yellow, green
// Blue is on for: light blue, blue, purple, white
// Therefore, the frequency of the pulse measured on PF2 is 1/8 of
// the frequency of the Timer2A interrupts.
#include <stdint.h>
#include "PLL.h"
#include "Timer2.h"
#include "../inc/tm4c123gh6pm.h"
#include "ST7735.h"
#include "ADCSWTrigger.h"
#include "Switch.h"


#define PF1       (*((volatile uint32_t *)0x40025008))
#define PF2       (*((volatile uint32_t *)0x40025010))
#define PF3       (*((volatile uint32_t *)0x40025020))
#define LEDS      (*((volatile uint32_t *)0x40025038))
#define RED       0x02
#define BLUE      0x04
#define GREEN     0x08
#define NELEMS(x)  (sizeof(x) / sizeof((x)[0]))
#define WHEELSIZE 8           // must be an integer multiple of 2
                              //    red, yellow,    green, light blue, blue, purple,   white,          dark
const uint32_t COLORWHEEL[WHEELSIZE] = {RED, RED+GREEN, GREEN, GREEN+BLUE, BLUE, BLUE+RED, RED+GREEN+BLUE, 0};
uint16_t currPinState;
uint16_t nextPinState;
uint8_t pinPressed;
uint16_t buttonPressed;
uint16_t currRectState;
uint16_t nextRectState;
uint32_t a = 10000000;
uint16_t pinNumber[4]= {0};
char presidentCandidates[3][10] = {"Bard","Telang","Valvano"};
void DisableInterrupts(void); // Disable interrupts
void EnableInterrupts(void);  // Enable interrupts
void WaitForInterrupt(void);  // low power mode

void UserTask(void){
  static uint32_t i = 0;
  LEDS = COLORWHEEL[i&(WHEELSIZE-1)];
  i = i + 1;
}



void SelectionScreenInit(){
	ST7735_FillScreen(ST7735_BLACK);
	ST7735_DrawStringS(1,0,"Presidents",ST7735_YELLOW,2);
	for(a = 0; a< NELEMS(presidentCandidates);a++){
		DrawPresidentRect(a);
		ST7735_DrawStringUnfixed(30,27+(a*33),presidentCandidates[a],ST7735_YELLOW,1);
		ST7735_DrawSquare(14,25+(a*33),9,ST7735_YELLOW);		
	}
}

int main(void){ volatile uint32_t delay;
  PLL_Init(Bus80MHz);              // bus clock at 80 MHz
	ADC0_InitSWTriggerSeq3_Ch9();
	PortE_Switch_Init();
	ST7735_InitR(INITR_REDTAB);
	PinScreenInit();
	currPinState = ADCPinState();
	SelectPin(currPinState); //this will need to check the adc... adc needs to be init and running for this to work
	pinPressed = 0;
	while(1){
		ST7735_DrawChar(0,20,(char)(currPinState+48),ST7735_YELLOW,ST7735_BLACK,2);
		nextPinState = ADCPinState();
		if(currPinState != nextPinState){
			DeselectPin(currPinState);
			SelectPin(nextPinState);
			currPinState = nextPinState;
		}
		//buttonPressed = Switch_Input();
		//ST7735_DrawChar(0,20,(char)(buttonPressed+48),ST7735_YELLOW,ST7735_BLACK,2);
		if(Switch_Input()==4){
			pinNumber[pinPressed] = currPinState;
			pinPressed++;
			DrawPinAsterick(pinPressed);
			if(pinPressed==4){
				break;
			}
		}
	}
	while(a!=0){a--;}
	SelectionScreenInit();
	currRectState = ADCRectState(4); 
	SelectSquare(currRectState);
	while(1){
		ST7735_DrawChar(0,20,(char)(currRectState+48),ST7735_YELLOW,ST7735_BLACK,2);
		nextRectState = ADCRectState(4);
		if(currRectState != nextRectState){
			DeselectSquare(currRectState);
			SelectSquare(nextRectState);
			currRectState = nextRectState;
		}
	}
	
	
	/*
  SYSCTL_RCGCGPIO_R |= 0x20;       // activate port F
  delay = SYSCTL_RCGCGPIO_R;       // allow time to finish activating
  GPIO_PORTF_DIR_R |= 0x0E;        // make PF3-1 output (PF3-1 built-in LEDs)
  GPIO_PORTF_AFSEL_R &= ~0x0E;     // disable alt funct on PF3-1
  GPIO_PORTF_DEN_R |= 0x0E;        // enable digital I/O on PF3-1
                                   // configure PF3-1 as GPIO
  GPIO_PORTF_PCTL_R = (GPIO_PORTF_PCTL_R&0xFFFF000F)+0x00000000;
  GPIO_PORTF_AMSEL_R = 0;          // disable analog functionality on PF
  LEDS = 0;                        // turn all LEDs off
//  Timer2_Init(&UserTask, 4000);    // initialize timer2 (20,000 Hz)
  Timer2_Init(&UserTask, 5000000); // initialize timer2 (16 Hz)
//  Timer2_Init(&UserTask, 80000000);// initialize timer2 (1 Hz)
//  Timer2_Init(&UserTask, 0xFFFFFFFF); // initialize timer2 (slowest rate)
	
  EnableInterrupts();

  while(1){
    WaitForInterrupt();
  }
	*/
}

